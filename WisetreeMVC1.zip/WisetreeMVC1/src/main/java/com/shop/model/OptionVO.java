package com.shop.model;

import lombok.Data;

@Data
public class OptionVO {

	private Integer up_Code;
	private String up_Name;
	
	private Integer down_Code;
	private String down_Name;
}
